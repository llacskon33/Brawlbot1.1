COMPILAR SCRCPYFORANDROID CON GITHUB ACTIONS

1. Descomprime este ZIP.
2. Copia la carpeta .github a la raíz de tu copia/fork del proyecto ScrcpyForAndroid.
3. Comprueba que en esa raíz están también gradlew y la carpeta app.
4. Sube los cambios a GitHub.
5. Abre Actions y ejecuta “Compilar APK Scrcpy para Android TV”.
6. Al terminar, descarga el artefacto “scrcpy-android-tv-apk”.

El workflow compila la variante scrcpyDebug del proyecto original. No modifica
la interfaz para Android TV ni garantiza compatibilidad USB/OTG con el TCL.
La APK aún debe probarse en el televisor y el móvil reales.
