package com.pylamobile.bot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Rect as CvRect
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

enum class GameState {
    MATCH, LOBBY, END, LOADING, MATCH_MAKING, BRAWLER_SELECT, SHOP, POPUP,
    PRESTIGE, STAR_DROP, DAILY_WINS, TROPHY_REWARD, SHOWDOWN_EXIT, FRIEND_MENU
}

class StateResult(val state: GameState, val detail: String = "")

/**
 * Detecta en qué pantalla está Brawl Stars con "template matching" (OpenCV), igual que
 * state_finder.py de PylaAI: mismas plantillas, mismas regiones y mismo orden de comprobación.
 * Las regiones se anclan a izquierda/centro/derecha según su posición para móviles alargados.
 */
class StateFinder(private val ctx: Context) {
    private class Region(val x: Float, val y: Float, val w: Float, val h: Float)

    // Regiones de cfg/lobby_config.toml (px de 1920x1080)
    private val regions = mapOf(
        "powerpoint" to Region(1000f, 5f, 80f, 80f),
        "brawler_menu_heart" to Region(1050f, 0f, 500f, 110f),
        "brawler_menu_search" to Region(1320f, 0f, 300f, 100f),
        "close_popup" to Region(1740f, 140f, 140f, 100f),
        "lobby_menu" to Region(1790f, 20f, 75f, 65f),
        "brawl_pass_house" to Region(1750f, 0f, 169f, 100f),
        "go_back_arrow" to Region(0f, 0f, 175f, 110f),
        "star_drop" to Region(790f, 350f, 350f, 350f),
        "trophies_screen" to Region(1545f, 915f, 365f, 168f),
        "exit_match_making" to Region(0f, 925f, 340f, 135f),
        "prestige_continue" to Region(535f, 950f, 345f, 95f),
        "match_result" to Region(20f, 10f, 650f, 200f),
        "daily_wins" to Region(0f, 0f, 360f, 110f),
        "showdown_exit" to Region(800f, 930f, 340f, 130f),
        "friend_menu_icon" to Region(900f, 0f, 175f, 110f),
        "loading_logo" to Region(450f, 350f, 1100f, 450f)
    )

    private val ready: Boolean = try { OpenCVLoader.initDebug() } catch (e: Throwable) { false }
    private val assetIndex = HashMap<String, String>()          // nombre en minúsculas -> ruta del asset
    private val starDrops = ArrayList<String>()                  // rutas de star_drop_types con "star_drop"
    private val cache = HashMap<String, Mat?>()
    private var cacheK = -1f
    private val frameMat = Mat()
    private val rgbMat = Mat()

    init {
        for (dir in listOf("states", "end_results", "star_drop_types")) {
            val files = try { ctx.assets.list("templates/$dir") } catch (e: Exception) { null } ?: continue
            for (f in files) {
                val path = "templates/$dir/$f"
                assetIndex["$dir/${f.lowercase()}"] = path
                if (dir == "star_drop_types" && f.lowercase().contains("star_drop")) starDrops.add(path)
            }
        }
    }

    val available: Boolean get() = ready && assetIndex.isNotEmpty()

    private fun template(key: String, k: Float): Mat? {
        if (k != cacheK) { cache.clear(); cacheK = k }
        val path = assetIndex[key] ?: return null
        return templateByPath(path, k)
    }

    private fun templateByPath(path: String, k: Float): Mat? {
        if (k != cacheK) { cache.clear(); cacheK = k }
        if (cache.containsKey(path)) return cache[path]
        var out: Mat? = null
        try {
            val bmp = ctx.assets.open(path).use { BitmapFactory.decodeStream(it) }
            if (bmp != null) {
                val m = Mat()
                Utils.bitmapToMat(bmp, m)
                val rgb = Mat()
                Imgproc.cvtColor(m, rgb, Imgproc.COLOR_RGBA2RGB)
                val small = Mat()
                Imgproc.resize(rgb, small, Size(maxOf(1.0, rgb.cols() * k.toDouble()), maxOf(1.0, rgb.rows() * k.toDouble())), 0.0, 0.0, Imgproc.INTER_AREA)
                m.release(); rgb.release()
                out = small
            }
        } catch (e: Exception) { out = null }
        cache[path] = out
        return out
    }

    private var offL = 0f
    private var offR = 0f

    private fun matches(tpl: Mat?, regionName: String, k: Float, thr: Double): Boolean {
        if (tpl == null) return false
        val r = regions[regionName] ?: return false
        val capW = rgbMat.cols()
        val capH = rgbMat.rows()
        // margen para tolerar muescas / barras del sistema
        val m = 60f
        val cxL = r.x + r.w / 2f
        val x0L = r.x - m
        val x1L = r.x + r.w + m
        val x0: Float
        val x1: Float
        when {
            cxL < 640f -> { x0 = x0L * k + offL; x1 = x1L * k + offL }
            cxL > 1280f -> { x0 = capW - (1920f - x0L) * k + offR; x1 = capW - (1920f - x1L) * k + offR }
            else -> { x0 = capW / 2f + (x0L - 960f) * k; x1 = capW / 2f + (x1L - 960f) * k }
        }
        val y0 = (r.y - m) * k
        val y1 = (r.y + r.h + m) * k
        val ix0 = x0.toInt().coerceIn(0, capW)
        val ix1 = x1.toInt().coerceIn(0, capW)
        val iy0 = y0.toInt().coerceIn(0, capH)
        val iy1 = y1.toInt().coerceIn(0, capH)
        if (ix1 - ix0 < tpl.cols() || iy1 - iy0 < tpl.rows()) return false
        val crop = rgbMat.submat(CvRect(ix0, iy0, ix1 - ix0, iy1 - iy0))
        val res = Mat()
        return try {
            Imgproc.matchTemplate(crop, tpl, res, Imgproc.TM_CCOEFF_NORMED)
            val mm = Core.minMaxLoc(res)
            mm.maxVal > thr
        } catch (e: Exception) {
            false
        } finally {
            res.release(); crop.release()
        }
    }

    private fun has(dir: String, name: String, region: String, k: Float, thr: Double = 0.75) =
        matches(template("$dir/$name", k), region, k, thr)

    /** k = píxeles de captura por unidad L. */
    @Synchronized
    fun find(frame: Bitmap, k: Float, offLeft: Float = 0f, offRight: Float = 0f): StateResult {
        if (!available) return StateResult(GameState.MATCH)
        offL = offLeft; offR = offRight
        Utils.bitmapToMat(frame, frameMat)
        Imgproc.cvtColor(frameMat, rgbMat, Imgproc.COLOR_RGBA2RGB)

        // 1) fin de partida
        for ((name, label) in listOf("1st.png" to "trio_showdown_0", "2nd.png" to "trio_showdown_1",
            "3rd.png" to "trio_showdown_2", "3rd_alt.png" to "trio_showdown_2", "4th.png" to "trio_showdown_3")) {
            if (has("end_results", name, "match_result", k, 0.9)) return StateResult(GameState.END, label)
        }
        if (has("end_results", "victory.png", "match_result", k)) return StateResult(GameState.END, "victory")
        if (has("end_results", "defeat.png", "match_result", k)) return StateResult(GameState.END, "defeat")
        if (has("end_results", "draw.png", "match_result", k)) return StateResult(GameState.END, "draw")

        if (has("states", "loading_logo.png", "loading_logo", k)) return StateResult(GameState.LOADING)
        if (has("states", "lobby_menu.png", "lobby_menu", k)) return StateResult(GameState.LOBBY)
        if (has("states", "friend_menu_icon.png", "friend_menu_icon", k)) return StateResult(GameState.FRIEND_MENU)
        if (has("states", "exit_match_making.png", "exit_match_making", k)) return StateResult(GameState.MATCH_MAKING)
        if (has("states", "brawler_menu_heart.png", "brawler_menu_heart", k) ||
            has("states", "brawler_menu_search.png", "brawler_menu_search", k)) return StateResult(GameState.BRAWLER_SELECT)
        if (has("states", "powerpoint.png", "powerpoint", k)) return StateResult(GameState.SHOP)
        if (has("states", "close_popup.png", "close_popup", k)) return StateResult(GameState.POPUP)
        if (has("states", "brawl_pass_house.png", "brawl_pass_house", k) ||
            has("states", "go_back_arrow.png", "go_back_arrow", k)) return StateResult(GameState.SHOP)
        if (has("states", "prestige_continue.png", "prestige_continue", k)) return StateResult(GameState.PRESTIGE)
        for (p in starDrops) {
            if (matches(templateByPath(p, k), "star_drop", k, 0.75)) return StateResult(GameState.STAR_DROP)
        }
        if (has("states", "daily_wins.png", "daily_wins", k)) return StateResult(GameState.DAILY_WINS)
        if (has("states", "trophies_screen.png", "trophies_screen", k)) return StateResult(GameState.TROPHY_REWARD)
        if (has("states", "exit_outline.png", "showdown_exit", k)) return StateResult(GameState.SHOWDOWN_EXIT)
        return StateResult(GameState.MATCH)
    }

    fun close() {
        for (m in cache.values) m?.release()
        cache.clear()
        frameMat.release(); rgbMat.release()
    }
}
