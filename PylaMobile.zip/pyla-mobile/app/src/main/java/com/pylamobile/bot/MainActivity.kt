package com.pylamobile.bot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqProjection = 1001
    private lateinit var info: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 14f, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.setPadding(0, dp(10), 0, dp(4))
        return t
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(24), dp(18), dp(24))
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("Pyla Mobile", 26f, true))
        root.addView(label("IA para Brawl Stars que se ejecuta en tu móvil (basada en PylaAI). Úsala solo con una cuenta secundaria: los bots incumplen las normas de Supercell y pueden provocar el baneo."))

        info = label("", 13f)
        root.addView(info)

        root.addView(label("1. Permisos", 18f, true))
        root.addView(button("Activar servicio de accesibilidad (toques)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Busca «Pyla Mobile (toques)» y actívalo. Si sale bloqueado: Ajustes > Apps > Pyla Mobile > ⋮ > Permitir ajustes restringidos", Toast.LENGTH_LONG).show()
        })
        root.addView(button("Permitir mostrar sobre otras apps (panel)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        if (Build.VERSION.SDK_INT >= 33) {
            root.addView(button("Permitir notificaciones") {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 5)
            })
        }

        root.addView(label("2. Ajustes de juego", 18f, true))
        root.addView(label("Brawler que estás usando (para sus rangos)"))
        val names = Brawlers.names(this)
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        sp.setSelection(names.indexOf(Prefs.brawler(this)).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { Prefs.setBrawler(this@MainActivity, names[pos]) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(sp)

        root.addView(label("Hacia dónde avanza si no ve enemigos"))
        val sp2 = Spinner(this)
        sp2.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Arriba", "Derecha", "Abajo", "Izquierda"))
        sp2.setSelection(Prefs.heading(this))
        sp2.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { Prefs.setHeading(this@MainActivity, pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(sp2)

        root.addView(check("Seguir al compañero si no hay enemigos", Prefs.follow(this)) { Prefs.setFollow(this, it) })
        root.addView(check("Jugar el lobby solo (pulsar Jugar, pasar resultados, cerrar ofertas)", Prefs.autoLobby(this)) { Prefs.setAutoLobby(this, it) })
        root.addView(check("Usar NNAPI (acelerador del móvil, experimental)", Prefs.nnapi(this)) { Prefs.setNnapi(this, it) })
        root.addView(check("Mostrar cajas de depuración al arrancar (empeora un poco la detección)", Prefs.debugBoxes(this)) { Prefs.setDebugBoxes(this, it) })

        root.addView(label("3. Jugar", 18f, true))
        root.addView(label("Elige el brawler y el modo en el lobby de Brawl Stars (el bot no los cambia), pon el juego en horizontal y pulsa Iniciar."))
        root.addView(button("▶ Iniciar bot") { startBot() })
        root.addView(button("■ Detener bot") {
            startService(Intent(this, BotService::class.java).setAction(BotService.ACTION_STOP))
        })
        root.addView(button("Abrir Brawl Stars") { openGame() })
        root.addView(button("Borrar calibración de botones") {
            Prefs.clearPoints(this)
            Toast.makeText(this, "Calibración borrada", Toast.LENGTH_SHORT).show()
        })
        root.addView(label("Panel flotante durante el juego: ⏸ pausa · 🎯 calibrar botones (arrastra cada punto sobre su botón y vuelve a pulsar 🎯) · 🐞 cajas de depuración · ✖ parar.", 12f))
    }

    private fun check(text: String, value: Boolean, onChange: (Boolean) -> Unit): CheckBox {
        val c = CheckBox(this)
        c.text = text
        c.isChecked = value
        c.setOnCheckedChangeListener { _, v -> onChange(v) }
        return c
    }

    override fun onResume() {
        super.onResume()
        val a11y = TouchService.instance != null
        val overlay = Settings.canDrawOverlays(this)
        info.text = "Accesibilidad: " + (if (a11y) "✅ activa" else "❌ sin activar") +
            "\nSuperposición: " + (if (overlay) "✅ permitida" else "❌ sin permitir") +
            "\nBot: " + (if (BotService.running) "▶ en marcha" else "■ parado")
    }

    private fun startBot() {
        if (TouchService.instance == null) {
            Toast.makeText(this, "Primero activa el servicio de accesibilidad", Toast.LENGTH_LONG).show(); return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primero permite mostrar sobre otras apps", Toast.LENGTH_LONG).show(); return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqProjection)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqProjection) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val i = Intent(this, BotService::class.java)
                    .setAction(BotService.ACTION_START)
                    .putExtra(BotService.EXTRA_CODE, resultCode)
                    .putExtra(BotService.EXTRA_DATA, data)
                startForegroundService(i)
                openGame()
            } else {
                Toast.makeText(this, "Necesito el permiso de captura de pantalla", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openGame() {
        val i = packageManager.getLaunchIntentForPackage("com.supercell.brawlstars")
        if (i != null) startActivity(i)
        else Toast.makeText(this, "No encuentro Brawl Stars instalado", Toast.LENGTH_SHORT).show()
    }
}
