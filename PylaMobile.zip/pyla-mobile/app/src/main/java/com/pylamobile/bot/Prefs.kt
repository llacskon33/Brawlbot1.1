package com.pylamobile.bot

import android.content.Context
import android.content.SharedPreferences
import android.graphics.PointF

/** Ajustes guardados de la app. */
object Prefs {
    private fun sp(c: Context): SharedPreferences = c.getSharedPreferences("pyla", Context.MODE_PRIVATE)

    fun brawler(c: Context): String = sp(c).getString("brawler", "shelly") ?: "shelly"
    fun setBrawler(c: Context, v: String) = sp(c).edit().putString("brawler", v).apply()

    /** 0 = arriba, 1 = derecha, 2 = abajo, 3 = izquierda */
    fun heading(c: Context): Int = sp(c).getInt("heading", 0)
    fun setHeading(c: Context, v: Int) = sp(c).edit().putInt("heading", v).apply()

    fun follow(c: Context): Boolean = sp(c).getBoolean("follow", false)
    fun setFollow(c: Context, v: Boolean) = sp(c).edit().putBoolean("follow", v).apply()

    /** Pulsar Jugar, pasar pantallas de resultados, cerrar ofertas, etc. */
    fun autoLobby(c: Context): Boolean = sp(c).getBoolean("autoLobby", true)
    fun setAutoLobby(c: Context, v: Boolean) = sp(c).edit().putBoolean("autoLobby", v).apply()

    fun nnapi(c: Context): Boolean = sp(c).getBoolean("nnapi", false)
    fun setNnapi(c: Context, v: Boolean) = sp(c).edit().putBoolean("nnapi", v).apply()

    fun debugBoxes(c: Context): Boolean = sp(c).getBoolean("debugBoxes", false)
    fun setDebugBoxes(c: Context, v: Boolean) = sp(c).edit().putBoolean("debugBoxes", v).apply()

    /** Posición calibrada de un botón, guardada como fracción de la pantalla (null = automática). */
    fun point(c: Context, b: Btn): PointF? {
        val s = sp(c).getString("pt_" + b.name, null) ?: return null
        val p = s.split(",")
        if (p.size != 2) return null
        return try { PointF(p[0].toFloat(), p[1].toFloat()) } catch (e: NumberFormatException) { null }
    }

    fun setPoint(c: Context, b: Btn, fx: Float, fy: Float) =
        sp(c).edit().putString("pt_" + b.name, "$fx,$fy").apply()

    fun clearPoints(c: Context) {
        val e = sp(c).edit()
        for (b in Btn.values()) e.remove("pt_" + b.name)
        e.apply()
    }
}
