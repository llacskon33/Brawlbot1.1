package com.pylamobile.core

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Caja en coordenadas de referencia "L" (1920x1080 del encuadre 16:9 del juego). */
data class Box(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val score: Float = 1f) {
    val cx: Float get() = (x1 + x2) / 2f
    val cy: Float get() = (y1 + y2) / 2f
    val w: Float get() = x2 - x1
    val h: Float get() = y2 - y1
}

data class Vec(val x: Float, val y: Float) {
    val len: Float get() = hypot(x, y)
    operator fun unaryMinus() = Vec(-x, -y)
    fun isZero() = len < 1e-3f
}

object Geo {
    /** ¿El segmento A-B corta el rectángulo? (Liang-Barsky) */
    fun segmentHitsRect(ax: Float, ay: Float, bx: Float, by: Float,
                        rx1: Float, ry1: Float, rx2: Float, ry2: Float): Boolean {
        var t0 = 0f
        var t1 = 1f
        val dx = bx - ax
        val dy = by - ay
        val p = floatArrayOf(-dx, dx, -dy, dy)
        val q = floatArrayOf(ax - rx1, rx2 - ax, ay - ry1, ry2 - ay)
        for (i in 0 until 4) {
            if (p[i] == 0f) {
                if (q[i] < 0f) return false
            } else {
                val r = q[i] / p[i]
                if (p[i] < 0f) {
                    if (r > t1) return false
                    if (r > t0) t0 = r
                } else {
                    if (r < t0) return false
                    if (r < t1) t1 = r
                }
            }
        }
        return true
    }

    fun pointRectDistSq(px: Float, py: Float, b: Box): Float {
        val dx = max(max(b.x1 - px, 0f), px - b.x2)
        val dy = max(max(b.y1 - py, 0f), py - b.y2)
        return dx * dx + dy * dy
    }

    /** Las paredes cortan la línea de visión entre dos puntos. */
    fun losBlocked(ax: Float, ay: Float, bx: Float, by: Float, walls: List<Box>): Boolean {
        if (walls.isEmpty()) return false
        val minX = min(ax, bx); val maxX = max(ax, bx)
        val minY = min(ay, by); val maxY = max(ay, by)
        for (w in walls) {
            if (maxX < w.x1 || minX > w.x2 || maxY < w.y1 || minY > w.y2) continue
            if (segmentHitsRect(ax, ay, bx, by, w.x1, w.y1, w.x2, w.y2)) return true
        }
        return false
    }

    /** Círculo (radio r) que barre de A a B choca con alguna caja. Misma idea que PylaAI. */
    fun sweptCircleBlocked(ax: Float, ay: Float, bx: Float, by: Float, r: Float, obstacles: List<Box>): Boolean {
        if (obstacles.isEmpty()) return false
        val minX = min(ax, bx); val maxX = max(ax, bx)
        val minY = min(ay, by); val maxY = max(ay, by)
        val r2 = r * r
        for (o in obstacles) {
            if (maxX < o.x1 - r || minX > o.x2 + r || maxY < o.y1 - r || minY > o.y2 + r) continue
            if (segmentHitsRect(ax, ay, bx, by, o.x1 - r, o.y1 - r, o.x2 + r, o.y2 + r)) {
                val startD = pointRectDistSq(ax, ay, o)
                val endD = pointRectDistSq(bx, by, o)
                // Si ya estamos pegados a la pared y nos alejamos, no cuenta como bloqueo.
                if (startD <= r2 && endD > startD) continue
                return true
            }
        }
        return false
    }
}

/** Transformación "letterbox" centrada (relleno 114/255) igual que PylaAI. */
class Letterbox(srcW: Int, srcH: Int, val dstW: Int, val dstH: Int) {
    val scale: Float = min(dstW.toFloat() / srcW, dstH.toFloat() / srcH)
    val newW: Int = Math.round(srcW * scale)
    val newH: Int = Math.round(srcH * scale)
    val padX: Int = (dstW - newW) / 2
    val padY: Int = (dstH - newH) / 2
}
