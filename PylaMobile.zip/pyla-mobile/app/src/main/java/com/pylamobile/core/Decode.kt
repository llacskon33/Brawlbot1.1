package com.pylamobile.core

import kotlin.math.max
import kotlin.math.min

/** Detección en píxeles del modelo (antes de deshacer el letterbox). */
class RawDet(val x1: Float, val y1: Float, val x2: Float, val y2: Float,
             val score: Float, val cls: Int)

/** Entidades detectadas, ya en coordenadas L. */
class Entities(
    val player: Box?,
    val enemies: List<Box>,
    val teammates: List<Box>,
    val enemySpawnables: List<Box>
)

object EntityDecoder {
    const val CLS_PLAYER = 0
    const val CLS_TEAMMATE = 1
    const val CLS_ENEMY = 2
    const val CLS_TEAMMATE_SPAWN = 3
    const val CLS_ENEMY_SPAWN = 4
    const val NUM_CLASSES = 6

    /**
     * Salida "pose" YOLO clásica: [1, 4 + clases + kpt(3), anchors], canal primero.
     * Para mainInGameModel.onnx: 13 canales x 5040 anclas.
     */
    fun decode(raw: FloatArray, channels: Int, anchors: Int, threshold: Float, iou: Float = 0.6f): List<RawDet> {
        val dets = ArrayList<RawDet>()
        for (i in 0 until anchors) {
            var best = -1
            var bestScore = 0f
            for (c in 0 until NUM_CLASSES) {
                val s = raw[(4 + c) * anchors + i]
                if (s > bestScore) { bestScore = s; best = c }
            }
            if (best < 0 || bestScore < threshold) continue
            val cx = raw[i]
            val cy = raw[anchors + i]
            val w = raw[2 * anchors + i]
            val h = raw[3 * anchors + i]
            if (!(w > 0f && h > 0f)) continue
            dets.add(RawDet(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f, bestScore, best))
        }
        return nmsPerClass(dets, iou)
    }

    fun nmsPerClass(dets: List<RawDet>, iouThr: Float): List<RawDet> {
        val out = ArrayList<RawDet>()
        for (cls in dets.map { it.cls }.distinct()) {
            val group = dets.filter { it.cls == cls }.sortedByDescending { it.score }
            val kept = ArrayList<RawDet>()
            for (d in group) {
                var ok = true
                for (k in kept) {
                    if (iou(d, k) > iouThr) { ok = false; break }
                }
                if (ok) kept.add(d)
            }
            out.addAll(kept)
        }
        return out
    }

    private fun iou(a: RawDet, b: RawDet): Float {
        val ix = max(0f, min(a.x2, b.x2) - max(a.x1, b.x1))
        val iy = max(0f, min(a.y2, b.y2) - max(a.y1, b.y1))
        val inter = ix * iy
        val ua = (a.x2 - a.x1) * (a.y2 - a.y1) + (b.x2 - b.x1) * (b.y2 - b.y1) - inter
        return inter / (ua + 1e-6f)
    }

    /**
     * Convierte detecciones del modelo a coordenadas L.
     * lb: letterbox del modelo, viewW/viewH: tamaño del encuadre en píxeles de captura,
     * lScale: 1080 / viewH.
     */
    fun toEntities(dets: List<RawDet>, lb: Letterbox, viewW: Int, viewH: Int, lScale: Float): Entities {
        fun conv(d: RawDet): Box {
            val x1 = ((d.x1 - lb.padX) / lb.scale).coerceIn(0f, viewW.toFloat()) * lScale
            val y1 = ((d.y1 - lb.padY) / lb.scale).coerceIn(0f, viewH.toFloat()) * lScale
            val x2 = ((d.x2 - lb.padX) / lb.scale).coerceIn(0f, viewW.toFloat()) * lScale
            val y2 = ((d.y2 - lb.padY) / lb.scale).coerceIn(0f, viewH.toFloat()) * lScale
            return Box(x1, y1, x2, y2, d.score)
        }
        val player = dets.filter { it.cls == CLS_PLAYER }.maxByOrNull { it.score }?.let { conv(it) }
        return Entities(
            player = player,
            enemies = dets.filter { it.cls == CLS_ENEMY }.map { conv(it) },
            teammates = dets.filter { it.cls == CLS_TEAMMATE }.map { conv(it) },
            enemySpawnables = dets.filter { it.cls == CLS_ENEMY_SPAWN }.map { conv(it) }
        )
    }
}
