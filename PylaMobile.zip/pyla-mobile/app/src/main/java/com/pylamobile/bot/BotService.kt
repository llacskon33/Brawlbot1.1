package com.pylamobile.bot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.RectF
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import com.pylamobile.core.Box
import com.pylamobile.core.GameFrame
import com.pylamobile.core.Heading
import com.pylamobile.core.Policy
import kotlin.random.Random

/**
 * Servicio en primer plano: captura la pantalla, detecta con los modelos de PylaAI,
 * decide con la estrategia y manda los toques a TouchService.
 */
class BotService : Service(), Overlay.Callbacks {
    companion object {
        const val ACTION_START = "com.pylamobile.bot.START"
        const val ACTION_STOP = "com.pylamobile.bot.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        @Volatile var running = false
    }

    private var projection: MediaProjection? = null
    private var capture: Capture? = null
    private var capThread: HandlerThread? = null
    private var thread: Thread? = null
    private var overlay: Overlay? = null

    @Volatile private var alive = false
    @Volatile private var paused = false
    @Volatile private var calibrating = false
    @Volatile private var debug = false
    @Volatile private var geoNow: ScreenGeo? = null
    private val mainHandler = Handler(android.os.Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { shutdown(); return START_NOT_STICKY }
            ACTION_START -> if (!alive) startBot(intent)
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun startBot(intent: Intent) {
        startForegroundCompat()
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopSelf(); return }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        val ct = HandlerThread("pyla-capture")
        ct.start()
        capThread = ct
        val capHandler = Handler(ct.looper)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { mainHandler.post { shutdown() } }
        }, capHandler)
        val cap = Capture(this, proj, capHandler)
        cap.ensureSize()
        capture = cap
        geoNow = ScreenGeo(cap.screenW, cap.screenH)

        debug = Prefs.debugBoxes(this)
        val ov = Overlay(this, this)
        overlay = ov
        ov.show()
        if (debug) ov.showBoxes(true)

        alive = true
        running = true
        val t = Thread({ runLoop() }, "pyla-bot")
        t.start()
        thread = t
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pyla", "Pyla Mobile", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "pyla")
            .setContentTitle("Pyla Mobile está jugando")
            .setContentText("Usa el panel flotante para pausar o parar")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun shutdown() {
        if (!alive && thread == null && projection == null) { stopSelf(); return }
        alive = false
        running = false
        TouchService.instance?.stopAll()
        overlay?.hide()
        val t = thread
        thread = null
        Thread {
            try { t?.join(1500) } catch (e: InterruptedException) { }
            try { capture?.release() } catch (e: Exception) { }
            capture = null
            try { projection?.stop() } catch (e: Exception) { }
            projection = null
            capThread?.quitSafely()
            capThread = null
        }.start()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        alive = false
        running = false
        super.onDestroy()
    }

    // ---------------------------------------------------------------- Overlay.Callbacks

    override fun onPauseToggle(): Boolean {
        paused = !paused
        if (paused) TouchService.instance?.stopAll()
        return paused
    }

    override fun onCalibrateToggle(): Boolean {
        val geo = geoNow ?: return false
        if (!calibrating) {
            calibrating = true
            TouchService.instance?.stopAll()
            overlay?.beginCalibration(geo, debug)
        } else {
            calibrating = false
            overlay?.endCalibration(geo, debug)
        }
        return calibrating
    }

    override fun onDebugToggle(): Boolean {
        debug = !debug
        Prefs.setDebugBoxes(this, debug)
        overlay?.showBoxes(debug)
        return debug
    }

    override fun onStop() { shutdown() }

    // ---------------------------------------------------------------- bucle principal

    @Volatile private var lastMenuLabel = "-"

    private fun status(s: String) { overlay?.setStatus(s) }

    private fun runLoop() {
        val cap = capture ?: return
        val detector: Detector
        try {
            detector = Detector(this, Prefs.nnapi(this))
        } catch (e: Throwable) {
            status("Error cargando modelos: " + e.message)
            return
        }
        val states = StateFinder(this)
        val brawler = Prefs.brawler(this)
        val policy = Policy(
            Brawlers.info(this, brawler),
            Heading.values()[Prefs.heading(this).coerceIn(0, 3)],
            Prefs.follow(this)
        )
        val autoLobby = Prefs.autoLobby(this)
        val rnd = Random(System.nanoTime())
        if (!states.available) status("Sin plantillas/OpenCV: solo juego en partida")

        var geo = ScreenGeo(cap.screenW, cap.screenH)
        var state = GameState.MATCH
        var detail = ""
        var lastState = 0L
        var lastSize = 0L
        var lastTerrain = 0L
        var lastAbility = 0L
        var abilityLock = 0L
        var lastPlayerSeen = SystemClock.elapsedRealtime()
        var lastProceed = 0L
        var superReady = false
        var gadgetReady = false
        var hyperReady = false
        val lastAction = HashMap<GameState, Long>()
        var frames = 0
        var fps = 0
        var fpsT = SystemClock.elapsedRealtime()
        var lastStatus = 0L
        var prevState = GameState.MATCH
        var pendingCount = 0

        try {
            while (alive) {
                val now = SystemClock.elapsedRealtime()
                val touch = TouchService.instance
                if (touch == null) { status("Activa el servicio de accesibilidad de Pyla Mobile"); sleepMs(400); continue }
                if (paused || calibrating) {
                    touch.stopAll(); policy.reset()
                    status(if (calibrating) "Calibrando: arrastra los puntos y pulsa 🎯" else "En pausa")
                    sleepMs(150); continue
                }

                if (now - lastSize > 1500) {
                    lastSize = now
                    if (cap.ensureSize()) {
                        geo = ScreenGeo(cap.screenW, cap.screenH)
                        geoNow = geo
                        detector.clearTerrain()
                    }
                }
                if (geo.w < geo.h) {
                    status("Pon el juego en horizontal")
                    touch.stopAll(); sleepMs(500); continue
                }

                val frame = cap.acquire()
                if (frame == null) { sleepMs(8); continue }
                // en partida solo se procesan fotogramas nuevos; en menús se reutiliza el último
                if (!cap.newFrame && state == GameState.MATCH) { sleepMs(15); continue }
                val k = cap.k

                // --- pantalla actual
                val every = if (state == GameState.MATCH) 700L else 500L
                if (now - lastState >= every) {
                    lastState = now
                    val offL = (geo.pos(this, Btn.JOYSTICK).x - geo.autoPos(Btn.JOYSTICK).x) * cap.capW / geo.w
                    val offR = (geo.pos(this, Btn.PROCEED).x - geo.autoPos(Btn.PROCEED).x) * cap.capW / geo.w
                    val r = states.find(frame, k, offL, offR)
                    if (state == GameState.MATCH && r.state != GameState.MATCH) {
                        // para salir de la partida hacen falta 2 lecturas seguidas (evita falsos positivos)
                        pendingCount++
                        if (pendingCount >= 2) { state = r.state; detail = r.detail; pendingCount = 0 }
                    } else {
                        pendingCount = 0
                        state = r.state
                        detail = r.detail
                    }
                    if (state == GameState.MATCH && prevState != GameState.MATCH) {
                        lastPlayerSeen = now; lastProceed = now; policy.reset()
                    }
                    prevState = state
                }

                if (state != GameState.MATCH) {
                    touch.stopAll(); policy.reset(); detector.clearTerrain()
                    if (autoLobby) menuAction(state, touch, geo, now, lastAction, rnd)
                    if (now - lastStatus > 500) { lastStatus = now; status("Pantalla: $state $detail | último toque: $lastMenuLabel") }
                    sleepMs(80)
                    continue
                }

                // --- en partida
                val view = cap.viewRect()
                val ents = try { detector.entities(frame, view, 0.55f) } catch (e: Exception) { null }
                if (now - lastTerrain >= 350 && detector.submitTerrain(frame, view, 0.6f)) lastTerrain = now

                val player = ents?.player
                if (ents == null || player == null) {
                    if (now - lastPlayerSeen > 1000) {
                        touch.releaseJoystick(); touch.holdAttackRelease(); policy.reset()
                    }
                    if (autoLobby && now - lastPlayerSeen > 8000 && now - lastProceed > 8000) {
                        val p = geo.pos(this, Btn.PROCEED)
                        touch.tap(p.x, p.y)
                        lastProceed = now
                    }
                    if (debug) overlay?.setBoxes(emptyList())
                    if (now - lastStatus > 500) { lastStatus = now; status("Buscando jugador… | $state | ${fps} fps") }
                    continue
                }
                lastPlayerSeen = now

                if (now - lastAbility > 120) {
                    lastAbility = now
                    if (now >= abilityLock) {
                        superReady = abilityReady(frame, cap, geo, Btn.SUPER)
                        gadgetReady = abilityReady(frame, cap, geo, Btn.GADGET)
                        hyperReady = abilityReady(frame, cap, geo, Btn.HYPER)
                    } else { superReady = false; gadgetReady = false; hyperReady = false }
                }

                val terrain = detector.terrain
                val d = policy.decide(GameFrame(now, player, ents, terrain, superReady, gadgetReady, hyperReady))

                // --- ejecutar la decisión
                val joy = geo.pos(this, Btn.JOYSTICK)
                val m = d.move
                if (m == null) touch.releaseJoystick()
                else touch.setJoystick(joy.x, joy.y, joy.x + m.x * geo.sh, joy.y + m.y * geo.sh)
                val atk = geo.pos(this, Btn.ATTACK)
                if (d.holdRelease) touch.holdAttackRelease()
                if (d.holdStart) touch.holdAttackStart(atk.x, atk.y)
                if (d.attackTap) touch.tap(atk.x, atk.y)
                if (d.useGadget) {
                    val p = geo.pos(this, Btn.GADGET); touch.tap(p.x, p.y)
                    gadgetReady = false; abilityLock = now + 1200
                }
                if (d.useHyper) {
                    val p = geo.pos(this, Btn.HYPER); touch.tap(p.x, p.y)
                    hyperReady = false; abilityLock = now + 1200
                }
                if (d.useSuper) {
                    val p = geo.pos(this, Btn.SUPER); touch.tap(p.x, p.y)
                    superReady = false; abilityLock = now + 1200
                }

                // --- depuración y estado
                if (debug) drawDebug(geo, ents.player, ents.enemies, ents.teammates, terrain)
                frames++
                if (now - fpsT >= 1000) { fps = frames; frames = 0; fpsT = now }
                if (now - lastStatus > 500) {
                    lastStatus = now
                    status("$brawler | $state | $fps fps | enemigos ${ents.enemies.size} | IA ${detector.entityMs}+${detector.terrainMs} ms" +
                        (if (superReady) " | SUPER" else ""))
                }
            }
        } catch (e: Throwable) {
            status("Error: " + e.message)
        } finally {
            TouchService.instance?.stopAll()
            detector.close()
            states.close()
        }
    }

    private fun sleepMs(ms: Long) {
        try { Thread.sleep(ms) } catch (e: InterruptedException) { }
    }

    /** Acciones de menú, igual que stage_manager.py de PylaAI. */
    private fun menuAction(
        state: GameState, touch: TouchService, geo: ScreenGeo, now: Long,
        last: HashMap<GameState, Long>, rnd: Random
    ) {
        val btn: Btn
        var gap = 2500L
        when (state) {
            GameState.LOBBY, GameState.END -> btn = Btn.PROCEED
            GameState.STAR_DROP, GameState.TROPHY_REWARD -> { btn = Btn.PROCEED; gap = 1200L }
            GameState.BRAWLER_SELECT, GameState.SHOP -> btn = Btn.QUIT_SHOP
            GameState.POPUP -> btn = Btn.CLOSE_POPUP
            GameState.PRESTIGE -> btn = Btn.CONTINUE_EQUIP
            GameState.DAILY_WINS -> btn = Btn.MIDDLE
            GameState.SHOWDOWN_EXIT -> btn = Btn.EXIT_SHOWDOWN
            GameState.FRIEND_MENU -> btn = Btn.EXIT_FRIEND
            else -> return   // MATCH_MAKING, LOADING: esperar
        }
        if (now - (last[state] ?: 0L) < gap) return
        last[state] = now
        lastMenuLabel = btn.label
        val p = geo.pos(this, btn)
        touch.tap(p.x + rnd.nextInt(-8, 9), p.y + rnd.nextInt(-8, 9))
    }

    // ---------------------------------------------------------------- super / gadget / hipercarga listos

    private class Hsv(val hLo: Int, val hHi: Int, val sLo: Int, val vLo: Int, val minPx: Float, val halfW: Float, val halfH: Float)

    private val superHsv = Hsv(17, 27, 170, 200, 1800f, 50f, 50f)
    private val gadgetHsv = Hsv(57, 62, 219, 165, 1300f, 60f, 60f)
    private val hyperHsv = Hsv(137, 179, 158, 159, 1800f, 50f, 55f)

    /** Cuenta píxeles del color de "listo" alrededor del botón (como check_if_*_ready de PylaAI). */
    private fun abilityReady(frame: Bitmap, cap: Capture, geo: ScreenGeo, b: Btn): Boolean {
        val h = when (b) { Btn.SUPER -> superHsv; Btn.GADGET -> gadgetHsv; else -> hyperHsv }
        val p = geo.pos(this, b)
        val fx = cap.capW.toFloat() / geo.w
        val fy = cap.capH.toFloat() / geo.h
        val k = cap.k
        val x0 = ((p.x - h.halfW * geo.sh) * fx).toInt().coerceIn(0, frame.width)
        val x1 = ((p.x + h.halfW * geo.sh) * fx).toInt().coerceIn(0, frame.width)
        val y0 = ((p.y - h.halfH * geo.sh) * fy).toInt().coerceIn(0, frame.height)
        val y1 = ((p.y + h.halfH * geo.sh) * fy).toInt().coerceIn(0, frame.height)
        if (x1 <= x0 || y1 <= y0) return false
        val w = x1 - x0
        val hh = y1 - y0
        val px = IntArray(w * hh)
        frame.getPixels(px, 0, w, x0, y0, w, hh)
        var count = 0
        for (c in px) {
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val bl = c and 0xFF
            val mx = maxOf(r, g, bl)
            val mn = minOf(r, g, bl)
            if (mx < h.vLo) continue
            val s = if (mx == 0) 0 else 255 * (mx - mn) / mx
            if (s < h.sLo) continue
            val d = mx - mn
            val hue = if (d == 0) 0f else when (mx) {
                r -> 60f * (((g - bl).toFloat() / d) + (if (g < bl) 6f else 0f))
                g -> 60f * (((bl - r).toFloat() / d) + 2f)
                else -> 60f * (((r - g).toFloat() / d) + 4f)
            }
            val h2 = (hue / 2f).toInt()
            if (h2 in h.hLo..h.hHi) count++
        }
        return count > h.minPx * k * k
    }

    // ---------------------------------------------------------------- depuración

    private fun drawDebug(geo: ScreenGeo, player: Box?, enemies: List<Box>, mates: List<Box>, t: com.pylamobile.core.Terrain) {
        val list = ArrayList<DrawBox>()
        fun add(b: Box, color: Int, fill: Boolean = false) {
            list.add(DrawBox(RectF(geo.lx(b.x1), geo.ly(b.y1), geo.lx(b.x2), geo.ly(b.y2)), color, fill))
        }
        for (w in t.walls) add(w, 0xFF9E9E9E.toInt(), true)
        for (w in t.bushes) add(w, 0xFF2E7D32.toInt(), true)
        for (w in t.blockers) add(w, 0xFF00BCD4.toInt(), true)
        for (e in enemies) add(e, 0xFFFF1744.toInt())
        for (e in mates) add(e, 0xFF2979FF.toInt())
        if (player != null) add(player, 0xFF00E676.toInt())
        overlay?.setBoxes(list)
    }
}
