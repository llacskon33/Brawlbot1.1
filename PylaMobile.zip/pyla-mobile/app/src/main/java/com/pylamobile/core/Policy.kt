package com.pylamobile.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

const val TILE = 54f              // tamaño percibido de una casilla (px L)
const val JOYSTICK_RADIUS = 100f  // radio de arrastre del joystick (px L)
const val PLAYER_HIT_R = 53f      // círculo de colisión del jugador (px L)

/** Rangos de un brawler (px L), tomados de brawlers_info.json de PylaAI. */
data class BrawlerInfo(
    val safeRange: Float = 301f,
    val attackRange: Float = 490f,
    val superType: String = "damage",
    val superRange: Float = 490f,
    val ignoreWallsAttack: Boolean = false,
    val ignoreWallsSuper: Boolean = true,
    val holdAttack: Float = 0f
)

enum class Heading(val vec: Vec) {
    UP(Vec(0f, -1f)), RIGHT(Vec(1f, 0f)), DOWN(Vec(0f, 1f)), LEFT(Vec(-1f, 0f))
}

class GameFrame(
    val nowMs: Long,
    val player: Box,
    val entities: Entities,
    val terrain: Terrain,
    val superReady: Boolean,
    val gadgetReady: Boolean,
    val hyperReady: Boolean
)

class Decision(
    /** Dirección del joystick en px L (módulo = JOYSTICK_RADIUS) o null para soltarlo. */
    val move: Vec?,
    val attackTap: Boolean = false,
    val holdStart: Boolean = false,
    val holdRelease: Boolean = false,
    val useSuper: Boolean = false,
    val useGadget: Boolean = false,
    val useHyper: Boolean = false
)

/**
 * Estilo de juego: avanza hacia el rumbo elegido, se acerca al enemigo hasta el rango seguro,
 * se aleja si está más cerca, ataca cuando es alcanzable y usa super/gadget/hipercarga.
 * Basado en los playstyles "default_up/default_right" de PylaAI.
 */
class Policy(
    var info: BrawlerInfo,
    var heading: Heading = Heading.UP,
    var followTeammate: Boolean = false,
    private val rng: Random = Random.Default
) {
    private var holdStartMs: Long? = null
    private var lastAttackMs = 0L

    // desatasco
    private var anchorX = 0f
    private var anchorY = 0f
    private var anchorMs = 0L
    private var hasAnchor = false
    private var unstuckUntil = 0L
    private var unstuckVec: Vec? = null
    private var rotSign = 1
    private var rotStep = 1

    fun reset() {
        holdStartMs = null
        hasAnchor = false
        unstuckUntil = 0L
        rotSign = 1; rotStep = 1
    }

    fun decide(f: GameFrame): Decision {
        val p = f.player
        val px = p.cx
        val py = p.cy
        val walls = f.terrain.walls
        val obstacles = walls + f.terrain.blockers

        var holdRelease = false
        val hs = holdStartMs
        if (hs != null && f.nowMs - hs >= (info.holdAttack * 1000f).toLong() + 50L) {
            holdRelease = true
            holdStartMs = null
        }

        val enemies = if (f.entities.enemies.isNotEmpty()) f.entities.enemies else f.entities.enemySpawnables
        var raw: Vec?
        var attackTap = false
        var holdStart = false
        var useSuper = false
        var useGadget = false
        var useHyper = false

        if (enemies.isEmpty()) {
            raw = noEnemyMovement(f, obstacles)
        } else {
            val (ex, ey, dist) = closestEnemy(px, py, enemies, walls)
            val dx = ex - px
            val dy = ey - py
            val toward = dist > info.safeRange
            val sx = if (toward) 1f else -1f
            val options = listOf(Vec(sx * dx, sx * dy), Vec(0f, sx * dy), Vec(sx * dx, 0f))
            raw = options.firstOrNull { !it.isZero() && !pathBlocked(p, it, obstacles) }
            if (raw == null) {
                val alts = cardinals().shuffled(rng)
                raw = alts.firstOrNull { !pathBlocked(p, it, obstacles) } ?: options[0]
            }

            val holding = holdStartMs != null
            if (f.superReady && !holding) {
                val hittable = hittable(px, py, ex, ey, walls, info.ignoreWallsSuper)
                if (hittable && (dist <= info.superRange || info.superType == "spawnable" || info.superType == "other")) {
                    if (f.hyperReady) useHyper = true
                    useSuper = true
                }
            }
            if (dist <= info.attackRange && hittable(px, py, ex, ey, walls, info.ignoreWallsAttack)) {
                if (f.gadgetReady && !holding) useGadget = true
                if (info.holdAttack <= 0f) {
                    if (f.nowMs - lastAttackMs >= 120L) { attackTap = true; lastAttackMs = f.nowMs }
                } else if (holdStartMs == null) {
                    holdStartMs = f.nowMs
                    holdStart = true
                }
            }
        }

        val finalMove = applyUnstuck(raw, px, py, f.nowMs)
        val scaled = finalMove?.let {
            val l = it.len
            if (l < 1e-3f) null else Vec(it.x / l * JOYSTICK_RADIUS, it.y / l * JOYSTICK_RADIUS)
        }
        return Decision(scaled, attackTap, holdStart, holdRelease, useSuper, useGadget, useHyper)
    }

    private fun cardinals() = listOf(Vec(0f, -1f), Vec(-1f, 0f), Vec(0f, 1f), Vec(1f, 0f))

    private fun noEnemyMovement(f: GameFrame, obstacles: List<Box>): Vec? {
        val p = f.player
        if (followTeammate && f.entities.teammates.isNotEmpty()) {
            val t = f.entities.teammates.minByOrNull { hypot(it.cx - p.cx, it.cy - p.cy) }!!
            val d = hypot(t.cx - p.cx, t.cy - p.cy)
            if (d < 2.2f * TILE) return null
            val v = Vec(t.cx - p.cx, t.cy - p.cy)
            if (!pathBlocked(p, v, obstacles)) return v
        }
        val preferred = heading.vec
        if (!pathBlocked(p, preferred, obstacles)) return preferred
        val alts = cardinals().filter { it != preferred }.shuffled(rng)
        return alts.firstOrNull { !pathBlocked(p, it, obstacles) } ?: preferred
    }

    private fun closestEnemy(px: Float, py: Float, enemies: List<Box>, walls: List<Box>): Triple<Float, Float, Float> {
        var bestH: Triple<Float, Float, Float>? = null
        var bestU: Triple<Float, Float, Float>? = null
        for (e in enemies) {
            val d = hypot(e.cx - px, e.cy - py)
            val t = Triple(e.cx, e.cy, d)
            if (hittable(px, py, e.cx, e.cy, walls, info.ignoreWallsAttack)) {
                if (bestH == null || d < bestH.third) bestH = t
            } else if (bestU == null || d < bestU.third) bestU = t
        }
        return bestH ?: bestU!!
    }

    private fun hittable(px: Float, py: Float, ex: Float, ey: Float, walls: List<Box>, ignoreWalls: Boolean): Boolean {
        if (ignoreWalls) return true
        return !Geo.losBlocked(px, py, ex, ey, walls)
    }

    private fun pathBlocked(player: Box, dir: Vec, obstacles: List<Box>, distance: Float = TILE): Boolean {
        val l = dir.len
        if (l < 1f) return false
        val cx = player.cx
        val cy = player.y2 - PLAYER_HIT_R
        val nx = cx + dir.x / l * distance
        val ny = cy + dir.y / l * distance
        return Geo.sweptCircleBlocked(cx, cy, nx, ny, PLAYER_HIT_R, obstacles)
    }

    private fun rotate(v: Vec, a: Float): Vec {
        val c = cos(a); val s = sin(a)
        return Vec(v.x * c - v.y * s, v.x * s + v.y * c)
    }

    /** Si pedimos movimiento y el jugador no avanza durante 2,4 s, gira la dirección 1,4 s. */
    private fun applyUnstuck(raw: Vec?, px: Float, py: Float, now: Long): Vec? {
        if (now < unstuckUntil) return unstuckVec
        if (raw == null || raw.isZero()) { hasAnchor = false; return raw }
        if (!hasAnchor || hypot(px - anchorX, py - anchorY) > 0.6f * TILE) {
            anchorX = px; anchorY = py; anchorMs = now; hasAnchor = true
            rotSign = 1; rotStep = 1
            return raw
        }
        if (now - anchorMs > 2400L) {
            rotSign *= -1
            val v = rotate(raw, rotSign * rotStep * (PI.toFloat() / 4f))
            if (rotSign > 0) { rotStep++; if (rotStep > 4) rotStep = 1 }
            unstuckVec = v
            unstuckUntil = now + 1400L
            anchorMs = now + 1400L
            return v
        }
        return raw
    }
}
