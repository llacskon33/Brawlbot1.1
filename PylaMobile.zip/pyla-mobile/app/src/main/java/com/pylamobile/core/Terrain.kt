package com.pylamobile.core

import kotlin.math.ceil

/** Resultado del mapa: cajas en coordenadas L. */
class Terrain(
    val walls: List<Box>,      // paredes (incluye indestructibles y frágiles)
    val bushes: List<Box>,
    val blockers: List<Box>    // agua, vallas y fuera de mapa: bloquean el paso pero no la vista
) {
    companion object { val EMPTY = Terrain(emptyList(), emptyList(), emptyList()) }

    /** Mueve todo el mapa (px L). Sirve para compensar el desplazamiento de la cámara desde que se calculó. */
    fun shifted(dx: Float, dy: Float): Terrain {
        if ((dx == 0f && dy == 0f) || (walls.isEmpty() && bushes.isEmpty() && blockers.isEmpty())) return this
        fun List<Box>.mv(): List<Box> {
            val out = ArrayList<Box>(size)
            for (b in this) {
                val x1 = b.x1 + dx; val x2 = b.x2 + dx; val y1 = b.y1 + dy; val y2 = b.y2 + dy
                if (x2 < -200f || x1 > 2120f || y2 < -200f || y1 > 1280f) continue   // fuera de pantalla
                out.add(Box(x1, y1, x2, y2, b.score))
            }
            return out
        }
        return Terrain(walls.mv(), bushes.mv(), blockers.mv())
    }
}

/**
 * Convierte la segmentación semántica de tileDetector.onnx (ids por píxel + confianza)
 * en una rejilla de casillas de [tile] píxeles L.
 *
 * Clases del modelo: 0 suelo, 1 pared, 2 arbusto, 3 valla, 4 agua, 5 fuera de mapa,
 * 6 pared indestructible, 7..12 especiales, 13 frágil.
 */
object TerrainBuilder {
    private const val G_WALL = 0
    private const val G_BUSH = 1
    private const val G_FENCE = 2
    private const val G_WATER = 3
    private const val G_OOB = 4
    private const val GROUPS = 5

    private fun group(cls: Int): Int = when (cls) {
        1, 6, 13 -> G_WALL
        2 -> G_BUSH
        3 -> G_FENCE
        4 -> G_WATER
        5 -> G_OOB
        else -> -1
    }

    // confianza mínima y fracción mínima de la casilla por grupo
    private val minConf = floatArrayOf(0.60f, 0.60f, 0.65f, 0.75f, 0.0f)
    private val minFrac = floatArrayOf(0.30f, 0.45f, 0.25f, 0.35f, 0.50f)

    fun build(
        ids: ByteArray, conf: FloatArray, modelW: Int, modelH: Int,
        lb: Letterbox, lScale: Float, tile: Float = 54f, step: Int = 2,
        wallConf: Float = 0.60f
    ): Terrain {
        val mc = minConf.copyOf(); mc[G_WALL] = wallConf; mc[G_BUSH] = wallConf
        // coordenada L de un píxel del modelo: ((m - pad) / scale) * lScale
        val toL = lScale / lb.scale
        val viewLw = lb.newW / lb.scale * lScale
        val viewLh = lb.newH / lb.scale * lScale
        val gw = ceil(viewLw / tile).toInt() + 1
        val gh = ceil(viewLh / tile).toInt() + 1
        val counts = Array(GROUPS) { IntArray(gw * gh) }
        val totals = IntArray(gw * gh)

        var y = lb.padY
        while (y < lb.padY + lb.newH) {
            val cy = (((y - lb.padY) * toL) / tile).toInt().coerceIn(0, gh - 1)
            var x = lb.padX
            while (x < lb.padX + lb.newW) {
                val cx = (((x - lb.padX) * toL) / tile).toInt().coerceIn(0, gw - 1)
                val idx = y * modelW + x
                val cell = cy * gw + cx
                totals[cell]++
                val g = group(ids[idx].toInt() and 0xFF)
                if (g >= 0 && conf[idx] >= mc[g]) counts[g][cell]++
                x += step
            }
            y += step
        }

        val walls = ArrayList<Box>()
        val bushes = ArrayList<Box>()
        val blockers = ArrayList<Box>()
        for (cy in 0 until gh) for (cx in 0 until gw) {
            val cell = cy * gw + cx
            val total = totals[cell]
            if (total == 0) continue
            // grupo dominante de la casilla
            var bestG = -1
            var bestFrac = 0f
            for (g in 0 until GROUPS) {
                val f = counts[g][cell].toFloat() / total
                if (f >= minFrac[g] && f > bestFrac) { bestFrac = f; bestG = g }
            }
            if (bestG < 0) continue
            val b = Box(cx * tile, cy * tile, (cx + 1) * tile, (cy + 1) * tile, bestFrac)
            when (bestG) {
                G_WALL -> walls.add(b)
                G_BUSH -> bushes.add(b)
                else -> blockers.add(b)
            }
        }
        return Terrain(walls, bushes, blockers)
    }
}
