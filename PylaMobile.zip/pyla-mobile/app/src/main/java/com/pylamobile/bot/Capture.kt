package com.pylamobile.bot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * Captura de pantalla con MediaProjection a ~540 px de alto (la mitad de 1080p):
 * suficiente para los modelos y mucho más rápida que la resolución nativa.
 */
class Capture(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val handler: Handler
) {
    var screenW = 0; private set
    var screenH = 0; private set
    var capW = 0; private set
    var capH = 0; private set
    /** Píxeles de captura por unidad L (1080 de alto). */
    val k: Float get() = capH / 1080f

    private var dpi = 320
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var wide: Bitmap? = null
    private var frame: Bitmap? = null
    private var lastFrame: Bitmap? = null

    private fun measure(): Triple<Int, Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    /** Crea o recrea la captura si cambió el tamaño de la pantalla (p. ej. al girar). */
    @Synchronized
    fun ensureSize(): Boolean {
        val (w, h, d) = measure()
        if (w == screenW && h == screenH && display != null) return false
        screenW = w; screenH = h; dpi = d
        val q = 540f / h
        capH = 540
        capW = (w * q).toInt() and 1.inv()
        reader?.close()
        val r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        reader = r
        val disp = display
        if (disp == null) {
            display = projection.createVirtualDisplay(
                "PylaCapture", capW, capH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
            )
        } else {
            disp.resize(capW, capH, dpi)
            disp.surface = r.surface
        }
        wide = null; frame = null; lastFrame = null
        return true
    }

    /** Último fotograma disponible (reutiliza el bitmap: úsalo solo desde el hilo del bot). */
    @Synchronized
    fun acquire(): Bitmap? {
        val r = reader ?: return lastFrame
        val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return null
        try {
            val plane = img.planes[0]
            val w = plane.rowStride / plane.pixelStride
            var wb = wide
            if (wb == null || wb.width != w || wb.height != capH) {
                wb = Bitmap.createBitmap(w, capH, Bitmap.Config.ARGB_8888)
                wide = wb
            }
            wb.copyPixelsFromBuffer(plane.buffer)
            val out: Bitmap
            if (w == capW) {
                out = wb
            } else {
                var fb = frame
                if (fb == null || fb.width != capW || fb.height != capH) {
                    fb = Bitmap.createBitmap(capW, capH, Bitmap.Config.ARGB_8888)
                    frame = fb
                }
                Canvas(fb).drawBitmap(wb, Rect(0, 0, capW, capH), Rect(0, 0, capW, capH), null)
                out = fb
            }
            lastFrame = out
            return out
        } finally {
            img.close()
        }
    }

    /** Encuadre 16:9 central (en píxeles de captura) que se pasa a los modelos. */
    fun viewRect(): Rect {
        val vw = minOf(capW, (capH * 16f / 9f).toInt())
        val left = (capW - vw) / 2
        return Rect(left, 0, left + vw, capH)
    }

    @Synchronized
    fun release() {
        try { display?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        display = null; reader = null
    }
}
