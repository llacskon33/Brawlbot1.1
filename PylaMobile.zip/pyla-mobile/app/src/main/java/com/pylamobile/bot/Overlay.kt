package com.pylamobile.bot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class DrawBox(val rect: RectF, val color: Int, val fill: Boolean = false)

/** Vista de dibujo a pantalla completa: cajas de depuración y puntos de calibración. */
class CanvasView(ctx: Context) : View(ctx) {
    @Volatile var boxes: List<DrawBox> = emptyList()
    var dots: LinkedHashMap<Btn, PointF>? = null

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 30f }
    private var dragging: Btn? = null
    private val loc = IntArray(2)

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        for (b in boxes) {
            if (b.fill) { fillP.color = (b.color and 0x00FFFFFF) or 0x55000000; c.drawRect(b.rect, fillP) }
            stroke.color = b.color
            c.drawRect(b.rect, stroke)
        }
        val d = dots
        if (d != null) {
            for ((btn, p) in d) {
                fillP.color = 0xAAFFEB3B.toInt()
                c.drawCircle(p.x, p.y, 38f, fillP)
                stroke.color = Color.BLACK
                c.drawCircle(p.x, p.y, 38f, stroke)
                c.drawText(btn.label, p.x - 40f, p.y - 48f, text)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val d = dots ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                var best: Btn? = null
                var bd = 150f * 150f
                for ((b, p) in d) {
                    val dx = p.x - e.rawX
                    val dy = p.y - e.rawY
                    val dd = dx * dx + dy * dy
                    if (dd < bd) { bd = dd; best = b }
                }
                dragging = best
            }
            MotionEvent.ACTION_MOVE -> dragging?.let { d[it]?.set(e.rawX, e.rawY); invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = null
        }
        return true
    }
}

/**
 * Panel flotante (pausa / calibrar / cajas / parar) y lienzo opcional.
 * El panel usa FLAG_SECURE para que no salga en la captura que analiza la IA.
 */
class Overlay(private val ctx: Context, private val cb: Callbacks) {
    interface Callbacks {
        fun onPauseToggle(): Boolean          // devuelve true si queda en pausa
        fun onCalibrateToggle(): Boolean      // devuelve true si entra en calibración
        fun onDebugToggle(): Boolean
        fun onStop()
    }

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var panel: LinearLayout? = null
    private var status: TextView? = null
    private var canvas: CanvasView? = null
    private var canvasLp: WindowManager.LayoutParams? = null
    private var calibrating = false

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, ctx.resources.displayMetrics)

    private fun pill(label: String, onClick: (TextView) -> Unit): TextView {
        val t = TextView(ctx)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.setColor(0xFF37474F.toInt())
        bg.cornerRadius = dp(14f)
        t.background = bg
        t.setPadding(dp(14f).toInt(), dp(6f).toInt(), dp(14f).toInt(), dp(6f).toInt())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(3f).toInt(), 0, dp(3f).toInt(), 0)
        t.layoutParams = lp
        t.setOnClickListener { onClick(t) }
        return t
    }

    fun show() = main.post {
        if (panel != null) return@post
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        val bg = GradientDrawable()
        bg.setColor(0xCC000000.toInt())
        bg.cornerRadius = dp(12f)
        root.background = bg
        root.setPadding(dp(8f).toInt(), dp(6f).toInt(), dp(8f).toInt(), dp(6f).toInt())

        val st = TextView(ctx)
        st.setTextColor(Color.WHITE)
        st.textSize = 11f
        st.text = "Pyla Mobile"
        root.addView(st)
        status = st

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(pill("⏸") { t -> t.text = if (cb.onPauseToggle()) "▶" else "⏸" })
        row.addView(pill("🎯") { t -> t.alpha = if (cb.onCalibrateToggle()) 0.5f else 1f })
        row.addView(pill("🐞") { t -> t.alpha = if (cb.onDebugToggle()) 0.5f else 1f })
        row.addView(pill("✖") { cb.onStop() })
        root.addView(row)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        lp.y = dp(6f).toInt()
        try { wm.addView(root, lp); panel = root } catch (e: Exception) { }
    }

    fun setStatus(text: String) {
        main.post { status?.text = text }
    }

    private fun ensureCanvas(touchable: Boolean) {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val existing = canvas
        if (existing == null) {
            val v = CanvasView(ctx)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
            )
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            try { wm.addView(v, lp); canvas = v; canvasLp = lp } catch (e: Exception) { }
        } else {
            val lp = canvasLp ?: return
            lp.flags = flags
            try { wm.updateViewLayout(existing, lp) } catch (e: Exception) { }
        }
        // el panel debe quedar por encima: se vuelve a añadir
        panel?.let { p ->
            try {
                val lp = p.layoutParams
                wm.removeView(p); wm.addView(p, lp)
            } catch (e: Exception) { }
        }
    }

    private fun removeCanvas() {
        canvas?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        canvas = null; canvasLp = null
    }

    /** Cajas de depuración (ya en píxeles de pantalla). Pasar vacío o apagar para no dibujar nada. */
    fun showBoxes(on: Boolean) = main.post {
        if (calibrating) return@post
        if (on) ensureCanvas(false) else removeCanvas()
    }

    fun setBoxes(boxes: List<DrawBox>) {
        canvas?.let { it.boxes = boxes; it.postInvalidate() }
    }

    fun beginCalibration(geo: ScreenGeo, keepBoxes: Boolean) = main.post {
        calibrating = true
        ensureCanvas(true)
        val v = canvas ?: return@post
        v.boxes = emptyList()
        val map = LinkedHashMap<Btn, PointF>()
        for (b in Btn.values()) if (b.calibratable) map[b] = PointF(geo.pos(ctx, b).x, geo.pos(ctx, b).y)
        v.dots = map
        v.invalidate()
    }

    /** Guarda las posiciones arrastradas (como fracción de pantalla). */
    fun endCalibration(geo: ScreenGeo, restoreBoxes: Boolean) = main.post {
        val v = canvas
        val d = v?.dots
        if (d != null) {
            for ((b, p) in d) Prefs.setPoint(ctx, b, p.x / geo.w, p.y / geo.h)
        }
        v?.dots = null
        calibrating = false
        if (restoreBoxes) ensureCanvas(false) else removeCanvas()
    }

    fun hide() = main.post {
        removeCanvas()
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        panel = null; status = null
    }
}
