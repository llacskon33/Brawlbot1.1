package com.pylamobile.bot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * Inyecta los toques: un dedo mantenido para el joystick (que se va moviendo), otro dedo
 * para mantener el ataque (brawlers de "mantener y soltar") y toques cortos para
 * ataque / super / gadget / hipercarga / botones de menú.
 *
 * Android cancela un gesto en curso si se envía otro, así que TODO se manda junto en un único
 * gesto de ~[tickMs] ms y se encadena con el siguiente mediante StrokeDescription.continueStroke.
 */
class TouchService : AccessibilityService() {
    companion object {
        @Volatile var instance: TouchService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val lock = Any()
    private val tickMs = 80L

    // joystick
    private var joyWanted = false
    private var joyTx = 0f
    private var joyTy = 0f
    private var joyCx = 0f
    private var joyCy = 0f
    private var joyStroke: StrokeDescription? = null
    private var joyLastX = 0f
    private var joyLastY = 0f

    // ataque mantenido
    private var holdWanted = false
    private var holdX = 0f
    private var holdY = 0f
    private var holdStroke: StrokeDescription? = null

    // toques cortos pendientes
    private val taps = ArrayList<FloatArray>()
    private var inFlight = false
    private var flightStart = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- API (cualquier hilo)

    /** Mantiene el dedo del joystick en (cx,cy) arrastrado hasta (tx,ty). */
    fun setJoystick(cx: Float, cy: Float, tx: Float, ty: Float) {
        synchronized(lock) {
            joyWanted = true
            joyCx = cx; joyCy = cy
            joyTx = tx; joyTy = ty
        }
        handler.post { pump() }
    }

    fun releaseJoystick() {
        synchronized(lock) { joyWanted = false }
        handler.post { pump() }
    }

    fun tap(x: Float, y: Float) {
        synchronized(lock) {
            if (taps.size < 6) taps.add(floatArrayOf(x, y))
        }
        handler.post { pump() }
    }

    fun holdAttackStart(x: Float, y: Float) {
        synchronized(lock) { holdWanted = true; holdX = x; holdY = y }
        handler.post { pump() }
    }

    fun holdAttackRelease() {
        synchronized(lock) { holdWanted = false }
        handler.post { pump() }
    }

    fun stopAll() {
        synchronized(lock) {
            joyWanted = false
            holdWanted = false
            taps.clear()
        }
        handler.post { pump() }
    }

    // ---------------------------------------------------------------- bucle de gestos (hilo principal)

    private fun pump() {
        if (inFlight) {
            // vigilante: si Android no avisó del fin del gesto, se libera para no quedarse bloqueado
            if (SystemClock.uptimeMillis() - flightStart > 1500L) {
                synchronized(lock) { joyStroke = null; holdStroke = null }
                inFlight = false
            } else return
        }
        val builder = GestureDescription.Builder()
        var strokes = 0
        var newJoy: StrokeDescription? = null
        var newHold: StrokeDescription? = null
        var joyEnds = false
        var holdEnds = false
        var jlx = 0f
        var jly = 0f

        synchronized(lock) {
            // --- joystick
            if (joyWanted) {
                val sx = if (joyStroke == null) joyCx else joyLastX
                val sy = if (joyStroke == null) joyCy else joyLastY
                val path = Path()
                path.moveTo(sx, sy)
                path.lineTo(joyTx, joyTy)
                val prev = joyStroke
                val s = if (prev == null) StrokeDescription(path, 0, tickMs, true)
                else prev.continueStroke(path, 0, tickMs, true)
                builder.addStroke(s)
                newJoy = s; jlx = joyTx; jly = joyTy
                strokes++
            } else if (joyStroke != null) {
                val path = Path()
                path.moveTo(joyLastX, joyLastY)
                val s = joyStroke!!.continueStroke(path, 0, 20, false)
                builder.addStroke(s)
                joyEnds = true
                strokes++
            }
            // --- ataque mantenido
            if (holdWanted) {
                val path = Path()
                path.moveTo(holdX, holdY)
                val prev = holdStroke
                val s = if (prev == null) StrokeDescription(path, 0, tickMs, true)
                else prev.continueStroke(path, 0, tickMs, true)
                builder.addStroke(s)
                newHold = s
                strokes++
            } else if (holdStroke != null) {
                val path = Path()
                path.moveTo(holdX, holdY)
                val s = holdStroke!!.continueStroke(path, 0, 20, false)
                builder.addStroke(s)
                holdEnds = true
                strokes++
            }
            // --- toques cortos
            val maxStrokes = GestureDescription.getMaxStrokeCount()
            while (taps.isNotEmpty() && strokes < maxStrokes) {
                val t = taps.removeAt(0)
                val path = Path()
                path.moveTo(t[0], t[1])
                builder.addStroke(StrokeDescription(path, 0, 50))
                strokes++
            }
        }
        if (strokes == 0) return

        val callback = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                synchronized(lock) {
                    if (newJoy != null) { joyStroke = newJoy; joyLastX = jlx; joyLastY = jly }
                    if (joyEnds) joyStroke = null
                    if (newHold != null) holdStroke = newHold
                    if (holdEnds) holdStroke = null
                }
                inFlight = false
                pump()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                synchronized(lock) { joyStroke = null; holdStroke = null }
                inFlight = false
                handler.postDelayed({ pump() }, 30)
            }
        }
        inFlight = true
        flightStart = SystemClock.uptimeMillis()
        handler.postDelayed({ pump() }, 1700)
        val ok = try { dispatchGesture(builder.build(), callback, handler) } catch (e: Exception) { false }
        if (!ok) {
            inFlight = false
            handler.postDelayed({ pump() }, 60)
        }
    }
}
