package com.pylamobile.bot

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import ai.onnxruntime.providers.NNAPIFlags
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Build
import android.os.Process
import com.pylamobile.core.Entities
import com.pylamobile.core.EntityDecoder
import com.pylamobile.core.Letterbox
import com.pylamobile.core.Terrain
import com.pylamobile.core.TerrainBuilder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.EnumSet
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Los dos modelos de PylaAI con ONNX Runtime:
 *  - mainInGameModel.onnx: jugador / compañeros / enemigos (YOLO pose, 640x384). Va en el camino crítico.
 *  - tileDetector.onnx: paredes, arbustos, agua... (segmentación 832x480, ~4x más pesado).
 *    Se ejecuta en segundo plano con prioridad baja; la posición se corrige con [Motion].
 *
 * La primera vez se mide qué backend es más rápido en ESTE móvil (CPU con 2/4/6 hilos, XNNPACK, NNAPI)
 * comprobando además que el resultado sea el mismo que en CPU.
 */
class Detector(private val ctx: Context, private val onStatus: (String) -> Unit) {
    private class Backend(val name: String, val kind: Int, val threads: Int)   // kind: 0 CPU, 1 XNNPACK, 2 NNAPI

    private val env = OrtEnvironment.getEnvironment()
    private val cores = Runtime.getRuntime().availableProcessors()
    private val entitySession: OrtSession
    private val terrainSession: OrtSession
    val backendName: String

    // ---- entidades ----
    private val eW = 640
    private val eH = 384
    private val eBmp = Bitmap.createBitmap(eW, eH, Bitmap.Config.ARGB_8888)
    private val eCanvas = Canvas(eBmp)
    private val ePix = IntArray(eW * eH)
    private val eFloats = FloatArray(3 * eW * eH)
    private val eBuf: FloatBuffer = ByteBuffer.allocateDirect(3 * eW * eH * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private var eOut = FloatArray(0)

    // ---- terreno ----
    private val tW = 832
    private val tH = 480
    private val tBmp = Bitmap.createBitmap(tW, tH, Bitmap.Config.ARGB_8888)
    private val tCanvas = Canvas(tBmp)
    private val tPix = IntArray(tW * tH)
    private val tFloats = FloatArray(3 * tW * tH)
    private val tBuf: FloatBuffer = ByteBuffer.allocateDirect(3 * tW * tH * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val tIds = ByteArray(tW * tH)
    private val tConf = FloatArray(tW * tH)
    private val worker = Executors.newSingleThreadExecutor { r ->
        Thread {
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) } catch (e: Throwable) { }
            r.run()
        }
    }
    @Volatile private var busy = false

    @Volatile var terrain: Terrain = Terrain.EMPTY; private set
    /** Desplazamiento acumulado de la cámara (px de captura) en el momento del fotograma del que salió [terrain]. */
    @Volatile var terrainAnchorX = 0.0; private set
    @Volatile var terrainAnchorY = 0.0; private set
    @Volatile var terrainMs = 0L; private set
    @Volatile var entityMs = 0L; private set

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    init {
        val entityBytes = ctx.assets.open("models/mainInGameModel.onnx").use { it.readBytes() }
        val chosen = chooseBackend(entityBytes)
        backendName = chosen.name
        entitySession = create(entityBytes, chosen)
        val terrainBytes = ctx.assets.open("models/tileDetector.onnx").use { it.readBytes() }
        terrainSession = create(terrainBytes, Backend("cpu2", 0, 2))
    }

    // ------------------------------------------------------------------ selección de backend

    private fun create(bytes: ByteArray, b: Backend): OrtSession {
        val o = OrtSession.SessionOptions()
        o.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        when (b.kind) {
            0 -> o.setIntraOpNumThreads(b.threads)
            1 -> {
                o.setIntraOpNumThreads(1)
                o.addXnnpack(mapOf("intra_op_num_threads" to b.threads.toString()))
            }
            else -> {
                o.setIntraOpNumThreads(2)
                o.addNnapi(EnumSet.of(NNAPIFlags.USE_FP16))
            }
        }
        return env.createSession(bytes, o)
    }

    private fun candidates(): List<Backend> {
        val list = ArrayList<Backend>()
        val t1 = (cores / 2).coerceIn(2, 4)
        list.add(Backend("cpu$t1", 0, t1))
        for (t in listOf(2, 4, 6)) if (t != t1 && t <= cores) list.add(Backend("cpu$t", 0, t))
        for (t in listOf(4, 6)) if (t <= cores) list.add(Backend("xnnpack$t", 1, t))
        list.add(Backend("nnapi", 2, 1))
        return list
    }

    private fun chooseBackend(bytes: ByteArray): Backend {
        val cands = candidates()
        val key = Build.FINGERPRINT + "|"
        val cached = Prefs.backend(ctx)
        if (cached != null && cached.startsWith(key)) {
            val name = cached.removePrefix(key)
            cands.firstOrNull { it.name == name }?.let { return it }
        }

        // entrada fija con ruido para comparar velocidad y resultados
        val rnd = java.util.Random(7)
        val buf = ByteBuffer.allocateDirect(3 * eW * eH * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (i in 0 until 3 * eW * eH) buf.put(0.25f + rnd.nextFloat() * 0.5f)
        val shape = longArrayOf(1, 3, eH.toLong(), eW.toLong())

        var ref: FloatArray? = null
        var best: Backend? = null
        var bestMs = Long.MAX_VALUE
        for (c in cands) {
            onStatus("Midiendo velocidad del móvil (solo la 1ª vez): ${c.name}…")
            var s: OrtSession? = null
            try {
                s = create(bytes, c)
                val times = ArrayList<Long>()
                var out: FloatArray? = null
                for (i in 0 until 6) {
                    buf.rewind()
                    val t0 = System.nanoTime()
                    val tensor = OnnxTensor.createTensor(env, buf, shape)
                    val res = s.run(mapOf("images" to tensor))
                    val ot = res.get(0) as OnnxTensor
                    val fb = ot.floatBuffer
                    val arr = FloatArray(fb.remaining()); fb.get(arr)
                    val ms = (System.nanoTime() - t0) / 1_000_000
                    res.close(); tensor.close()
                    out = arr
                    if (i == 0 && ms > 6000) break            // demasiado lento: descartar
                    if (i >= 2) times.add(ms)
                }
                if (times.isEmpty() || out == null) continue
                if (ref == null) ref = out
                else if (!similar(ref, out)) continue         // resultados distintos a CPU: descartar
                times.sort()
                val med = times[times.size / 2]
                if (med < bestMs) { bestMs = med; best = c }
            } catch (e: Throwable) {
                // backend no disponible en este móvil
            } finally {
                try { s?.close() } catch (e: Throwable) { }
            }
        }
        val chosen = best ?: cands[0]
        Prefs.setBackend(ctx, key + chosen.name)
        onStatus("Backend elegido: ${chosen.name} (~${if (bestMs == Long.MAX_VALUE) -1 else bestMs} ms)")
        return chosen
    }

    private fun similar(a: FloatArray, b: FloatArray): Boolean {
        if (a.size != b.size) return false
        val anchors = a.size / 13
        var maxScore = 0f
        var boxSum = 0.0
        for (i in 0 until 4 * anchors) boxSum += abs(a[i] - b[i])
        for (i in 4 * anchors until 10 * anchors) {
            val d = abs(a[i] - b[i]); if (d > maxScore) maxScore = d
        }
        return maxScore < 0.1f && boxSum / (4 * anchors) < 3.0
    }

    // ------------------------------------------------------------------ inferencia

    /** Dibuja el encuadre en el lienzo del modelo con letterbox y lo pasa a CHW float. */
    private fun fill(
        frame: Bitmap, view: Rect, lb: Letterbox,
        bmp: Bitmap, canvas: Canvas, pix: IntArray, floats: FloatArray, buf: FloatBuffer
    ) {
        canvas.drawColor(Color.rgb(114, 114, 114))
        val dst = Rect(lb.padX, lb.padY, lb.padX + lb.newW, lb.padY + lb.newH)
        canvas.drawBitmap(frame, view, dst, paint)
        val w = bmp.width
        val h = bmp.height
        bmp.getPixels(pix, 0, w, 0, 0, w, h)
        val n = w * h
        for (i in 0 until n) {
            val p = pix[i]
            floats[i] = ((p shr 16) and 0xFF) / 255f
            floats[n + i] = ((p shr 8) and 0xFF) / 255f
            floats[2 * n + i] = (p and 0xFF) / 255f
        }
        buf.rewind()
        buf.put(floats)
        buf.rewind()
    }

    /** Detecta jugador, compañeros y enemigos. Coordenadas devueltas en referencia L. */
    fun entities(frame: Bitmap, view: Rect, threshold: Float): Entities {
        val t0 = System.nanoTime()
        val lb = Letterbox(view.width(), view.height(), eW, eH)
        fill(frame, view, lb, eBmp, eCanvas, ePix, eFloats, eBuf)
        val tensor = OnnxTensor.createTensor(env, eBuf, longArrayOf(1, 3, eH.toLong(), eW.toLong()))
        try {
            val result = entitySession.run(mapOf("images" to tensor))
            try {
                val out = result.get(0) as OnnxTensor
                val shape = (out.info as TensorInfo).shape   // [1, canales, anclas]
                val channels = shape[1].toInt()
                val anchors = shape[2].toInt()
                val fb = out.floatBuffer
                if (eOut.size != fb.remaining()) eOut = FloatArray(fb.remaining())
                fb.get(eOut)
                val dets = EntityDecoder.decode(eOut, channels, anchors, threshold)
                entityMs = (System.nanoTime() - t0) / 1_000_000
                return EntityDecoder.toEntities(dets, lb, view.width(), view.height(), 1080f / view.height())
            } finally {
                result.close()
            }
        } finally {
            tensor.close()
        }
    }

    /**
     * Lanza (en segundo plano) la detección de paredes. Si la anterior sigue en curso, no hace nada.
     * anchorX/Y: desplazamiento acumulado de la cámara en este fotograma (para recolocar el mapa después).
     */
    fun submitTerrain(frame: Bitmap, view: Rect, wallConf: Float, anchorX: Double, anchorY: Double): Boolean {
        if (busy) return false
        val lb = Letterbox(view.width(), view.height(), tW, tH)
        fill(frame, view, lb, tBmp, tCanvas, tPix, tFloats, tBuf)
        val lScale = 1080f / view.height()
        busy = true
        worker.execute {
            try {
                val t0 = System.nanoTime()
                val tensor = OnnxTensor.createTensor(env, tBuf, longArrayOf(1, 3, tH.toLong(), tW.toLong()))
                try {
                    val result = terrainSession.run(mapOf("images" to tensor))
                    try {
                        val ids = result.get("class_ids").get() as OnnxTensor
                        val conf = result.get("confidence").get() as OnnxTensor
                        ids.byteBuffer.get(tIds)
                        conf.floatBuffer.get(tConf)
                        val built = TerrainBuilder.build(tIds, tConf, tW, tH, lb, lScale, wallConf = wallConf)
                        terrainAnchorX = anchorX
                        terrainAnchorY = anchorY
                        terrain = built
                        terrainMs = (System.nanoTime() - t0) / 1_000_000
                    } finally {
                        result.close()
                    }
                } finally {
                    tensor.close()
                }
            } catch (e: Exception) {
                // se mantiene el último mapa
            } finally {
                busy = false
            }
        }
        return true
    }

    fun clearTerrain() { terrain = Terrain.EMPTY }

    fun close() {
        worker.shutdownNow()
        try { entitySession.close() } catch (e: Exception) { }
        try { terrainSession.close() } catch (e: Exception) { }
    }
}
