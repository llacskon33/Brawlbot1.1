package com.pylamobile.bot

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import com.pylamobile.core.Entities
import com.pylamobile.core.EntityDecoder
import com.pylamobile.core.Letterbox
import com.pylamobile.core.Terrain
import com.pylamobile.core.TerrainBuilder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.Executors

/**
 * Los dos modelos de PylaAI con ONNX Runtime:
 *  - mainInGameModel.onnx: jugador / compañeros / enemigos (YOLO pose, 640x384)
 *  - tileDetector.onnx: paredes, arbustos, agua... (segmentación, 832x480)
 */
class Detector(ctx: Context, useNnapi: Boolean) {
    private val env = OrtEnvironment.getEnvironment()
    private val entitySession: OrtSession
    private val terrainSession: OrtSession
    private val cores = Runtime.getRuntime().availableProcessors()

    // ---- entidades ----
    private val eW = 640
    private val eH = 384
    private val eBmp = Bitmap.createBitmap(eW, eH, Bitmap.Config.ARGB_8888)
    private val eCanvas = Canvas(eBmp)
    private val ePix = IntArray(eW * eH)
    private val eFloats = FloatArray(3 * eW * eH)
    private val eBuf: FloatBuffer = ByteBuffer.allocateDirect(3 * eW * eH * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private var eOut = FloatArray(0)

    // ---- terreno ----
    private val tW = 832
    private val tH = 480
    private val tBmp = Bitmap.createBitmap(tW, tH, Bitmap.Config.ARGB_8888)
    private val tCanvas = Canvas(tBmp)
    private val tPix = IntArray(tW * tH)
    private val tFloats = FloatArray(3 * tW * tH)
    private val tBuf: FloatBuffer = ByteBuffer.allocateDirect(3 * tW * tH * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val tIds = ByteArray(tW * tH)
    private val tConf = FloatArray(tW * tH)
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var busy = false

    @Volatile var terrain: Terrain = Terrain.EMPTY; private set
    @Volatile var terrainMs = 0L; private set
    @Volatile var entityMs = 0L; private set

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    init {
        entitySession = load(ctx, "models/mainInGameModel.onnx", useNnapi, minOf(4, maxOf(2, cores / 2)))
        terrainSession = load(ctx, "models/tileDetector.onnx", false, 2)
    }

    private fun load(ctx: Context, path: String, nnapi: Boolean, threads: Int): OrtSession {
        val bytes = ctx.assets.open(path).use { it.readBytes() }
        val opts = OrtSession.SessionOptions()
        opts.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        opts.setIntraOpNumThreads(threads)
        if (nnapi) {
            try { opts.addNnapi() } catch (e: Exception) { /* sin NNAPI: se usa CPU */ }
        }
        return env.createSession(bytes, opts)
    }

    /** Dibuja el encuadre en el lienzo del modelo con letterbox y lo pasa a CHW float. */
    private fun fill(
        frame: Bitmap, view: Rect, lb: Letterbox,
        bmp: Bitmap, canvas: Canvas, pix: IntArray, floats: FloatArray, buf: FloatBuffer
    ) {
        canvas.drawColor(Color.rgb(114, 114, 114))
        val dst = Rect(lb.padX, lb.padY, lb.padX + lb.newW, lb.padY + lb.newH)
        canvas.drawBitmap(frame, view, dst, paint)
        val w = bmp.width
        val h = bmp.height
        bmp.getPixels(pix, 0, w, 0, 0, w, h)
        val n = w * h
        for (i in 0 until n) {
            val p = pix[i]
            floats[i] = ((p shr 16) and 0xFF) / 255f
            floats[n + i] = ((p shr 8) and 0xFF) / 255f
            floats[2 * n + i] = (p and 0xFF) / 255f
        }
        buf.rewind()
        buf.put(floats)
        buf.rewind()
    }

    /** Detecta jugador, compañeros y enemigos. Coordenadas devueltas en referencia L. */
    fun entities(frame: Bitmap, view: Rect, threshold: Float): Entities {
        val t0 = System.nanoTime()
        val lb = Letterbox(view.width(), view.height(), eW, eH)
        fill(frame, view, lb, eBmp, eCanvas, ePix, eFloats, eBuf)
        val tensor = OnnxTensor.createTensor(env, eBuf, longArrayOf(1, 3, eH.toLong(), eW.toLong()))
        try {
            val result = entitySession.run(mapOf("images" to tensor))
            try {
                val out = result.get(0) as OnnxTensor
                val shape = (out.info as TensorInfo).shape   // [1, canales, anclas]
                val channels = shape[1].toInt()
                val anchors = shape[2].toInt()
                val fb = out.floatBuffer
                if (eOut.size != fb.remaining()) eOut = FloatArray(fb.remaining())
                fb.get(eOut)
                val dets = EntityDecoder.decode(eOut, channels, anchors, threshold)
                entityMs = (System.nanoTime() - t0) / 1_000_000
                return EntityDecoder.toEntities(dets, lb, view.width(), view.height(), 1080f / view.height())
            } finally {
                result.close()
            }
        } finally {
            tensor.close()
        }
    }

    /**
     * Lanza (en segundo plano) la detección de paredes. Si la anterior sigue en curso, no hace nada.
     * Devuelve true si se ha lanzado una nueva.
     */
    fun submitTerrain(frame: Bitmap, view: Rect, wallConf: Float): Boolean {
        if (busy) return false
        val lb = Letterbox(view.width(), view.height(), tW, tH)
        fill(frame, view, lb, tBmp, tCanvas, tPix, tFloats, tBuf)
        val lScale = 1080f / view.height()
        busy = true
        worker.execute {
            try {
                val t0 = System.nanoTime()
                val tensor = OnnxTensor.createTensor(env, tBuf, longArrayOf(1, 3, tH.toLong(), tW.toLong()))
                try {
                    val result = terrainSession.run(mapOf("images" to tensor))
                    try {
                        val ids = result.get("class_ids").get() as OnnxTensor
                        val conf = result.get("confidence").get() as OnnxTensor
                        ids.byteBuffer.get(tIds)
                        conf.floatBuffer.get(tConf)
                        terrain = TerrainBuilder.build(tIds, tConf, tW, tH, lb, lScale, wallConf = wallConf)
                        terrainMs = (System.nanoTime() - t0) / 1_000_000
                    } finally {
                        result.close()
                    }
                } finally {
                    tensor.close()
                }
            } catch (e: Exception) {
                // se mantiene el último mapa
            } finally {
                busy = false
            }
        }
        return true
    }

    fun clearTerrain() { terrain = Terrain.EMPTY }

    fun close() {
        worker.shutdownNow()
        try { entitySession.close() } catch (e: Exception) { }
        try { terrainSession.close() } catch (e: Exception) { }
    }
}
