package com.pylamobile.bot

import android.graphics.Bitmap
import android.graphics.Rect
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.abs

/**
 * Estima cuánto se mueve la cámara entre fotogramas (correlación de fase sobre la zona central,
 * sin HUD). Así las paredes calculadas hace 1-2 s se pueden recolocar sin volver a ejecutar
 * el modelo pesado de terreno.
 *
 * cumX / cumY: desplazamiento acumulado del CONTENIDO en píxeles de captura
 * (si la cámara va a la derecha, el contenido se mueve a la izquierda: cumX baja).
 */
class Motion {
    private val ok: Boolean = try { OpenCVLoader.initDebug() } catch (e: Throwable) { false }
    private val frameMat = Mat()
    private val gray = Mat()
    private val small = Mat()
    private val f32 = Mat()
    private val prev = Mat()
    private val win = Mat()
    private var hasPrev = false
    private var winCols = 0
    private var winRows = 0

    @Volatile var cumX = 0.0; private set
    @Volatile var cumY = 0.0; private set

    fun reset() { hasPrev = false; cumX = 0.0; cumY = 0.0 }

    fun update(frame: Bitmap, view: Rect) {
        if (!ok) return
        try {
            Utils.bitmapToMat(frame, frameMat)
            Imgproc.cvtColor(frameMat, gray, Imgproc.COLOR_RGBA2GRAY)
            val x0 = view.left + (view.width() * 0.20).toInt()
            val x1 = view.left + (view.width() * 0.80).toInt()
            val y0 = (view.height() * 0.10).toInt()
            val y1 = (view.height() * 0.85).toInt()
            val roi = gray.submat(y0, y1, x0, x1)
            Imgproc.resize(roi, small, Size(0.0, 0.0), 0.25, 0.25, Imgproc.INTER_AREA)
            roi.release()
            small.convertTo(f32, CvType.CV_32F)
            if (hasPrev && prev.cols() == f32.cols() && prev.rows() == f32.rows()) {
                if (winCols != f32.cols() || winRows != f32.rows()) {
                    Imgproc.createHanningWindow(win, f32.size(), CvType.CV_32F)
                    winCols = f32.cols(); winRows = f32.rows()
                }
                val resp = DoubleArray(1)
                val sh = Imgproc.phaseCorrelate(prev, f32, win, resp)
                // solo se aceptan medidas fiables y razonables
                if (resp[0] >= 0.3 && abs(sh.x) < f32.cols() / 3.0 && abs(sh.y) < f32.rows() / 3.0) {
                    cumX += sh.x * 4.0
                    cumY += sh.y * 4.0
                }
            }
            f32.copyTo(prev)
            hasPrev = true
        } catch (e: Throwable) {
            hasPrev = false
        }
    }

    fun release() {
        frameMat.release(); gray.release(); small.release(); f32.release(); prev.release(); win.release()
    }
}
