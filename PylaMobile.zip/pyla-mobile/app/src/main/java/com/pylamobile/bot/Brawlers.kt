package com.pylamobile.bot

import android.content.Context
import com.pylamobile.core.BrawlerInfo
import org.json.JSONObject

/** Rangos de cada brawler (assets/cfg/brawlers_info.json, copiado de PylaAI). */
object Brawlers {
    private var cache: Map<String, BrawlerInfo>? = null

    fun all(c: Context): Map<String, BrawlerInfo> {
        cache?.let { return it }
        val map = LinkedHashMap<String, BrawlerInfo>()
        try {
            val text = c.assets.open("cfg/brawlers_info.json").bufferedReader().use { it.readText() }
            val root = JSONObject(text)
            val keys = root.keys().asSequence().sorted().toList()
            for (k in keys) {
                val o = root.getJSONObject(k)
                map[k] = BrawlerInfo(
                    safeRange = o.optDouble("safe_range", 301.0).toFloat(),
                    attackRange = o.optDouble("attack_range", 490.0).toFloat(),
                    superType = o.optString("super_type", "damage"),
                    superRange = o.optDouble("super_range", 490.0).toFloat(),
                    ignoreWallsAttack = o.optBoolean("ignore_walls_for_attacks", false),
                    ignoreWallsSuper = o.optBoolean("ignore_walls_for_supers", true),
                    holdAttack = o.optDouble("hold_attack", 0.0).toFloat()
                )
            }
        } catch (e: Exception) {
            map["shelly"] = BrawlerInfo()
        }
        cache = map
        return map
    }

    fun names(c: Context): List<String> = all(c).keys.toList()

    fun info(c: Context, name: String): BrawlerInfo = all(c)[name] ?: BrawlerInfo()
}
