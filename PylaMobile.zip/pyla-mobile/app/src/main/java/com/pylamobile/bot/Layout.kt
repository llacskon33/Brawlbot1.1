package com.pylamobile.bot

import android.content.Context
import android.graphics.PointF

enum class Anchor { LEFT, CENTER, RIGHT }

/**
 * Botones del juego en la referencia 1920x1080 de PylaAI (cfg/buttons_config.toml).
 * La interfaz de Brawl Stars se pega a los bordes de la pantalla, así que cada botón
 * se ancla a la izquierda, al centro o a la derecha para móviles más alargados (20:9).
 */
enum class Btn(val lx: Float, val ly: Float, val anchor: Anchor, val label: String, val calibratable: Boolean) {
    JOYSTICK(180f, 900f, Anchor.LEFT, "Joystick", true),
    ATTACK(1723f, 793f, Anchor.RIGHT, "Ataque", true),
    SUPER(1512f, 881f, Anchor.RIGHT, "Super", true),
    GADGET(1645f, 989f, Anchor.RIGHT, "Gadget", true),
    HYPER(1400f, 990f, Anchor.RIGHT, "Hipercarga", true),
    PROCEED(1660f, 980f, Anchor.RIGHT, "Jugar/Continuar", true),

    GOT_IT(960f, 980f, Anchor.CENTER, "Entendido", false),
    CONTINUE_EQUIP(700f, 1000f, Anchor.CENTER, "Continuar", false),
    EXIT_SHOWDOWN(950f, 1000f, Anchor.CENTER, "Salir Showdown", false),
    EXIT_FRIEND(1830f, 50f, Anchor.RIGHT, "Cerrar amigos", false),
    QUIT_SHOP(100f, 60f, Anchor.LEFT, "Atrás", false),
    MIDDLE(960f, 540f, Anchor.CENTER, "Centro", false),
    CLOSE_POPUP(1810f, 190f, Anchor.RIGHT, "Cerrar oferta", false)
}

/** Geometría de la pantalla real (px) y conversión entre referencia L (1920x1080) y píxeles. */
class ScreenGeo(val w: Int, val h: Int) {
    /** Píxeles de pantalla por unidad L. */
    val sh: Float = h / 1080f

    /** Ancho en pantalla del encuadre 16:9 que ven los modelos. */
    val viewW: Float = minOf(w.toFloat(), h * 16f / 9f)
    val viewLeft: Float = (w - viewW) / 2f

    fun lx(l: Float): Float = viewLeft + l * sh
    fun ly(l: Float): Float = l * sh

    fun pos(c: Context, b: Btn): PointF {
        Prefs.point(c, b)?.let { return PointF(it.x * w, it.y * h) }
        return autoPos(b)
    }

    fun autoPos(b: Btn): PointF {
        val y = b.ly * sh
        val x = when (b.anchor) {
            Anchor.LEFT -> b.lx * sh
            Anchor.RIGHT -> w - (1920f - b.lx) * sh
            Anchor.CENTER -> w / 2f + (b.lx - 960f) * sh
        }
        return PointF(x, y)
    }
}
