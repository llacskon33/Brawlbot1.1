plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pylamobile.bot"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pylamobile.bot"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // Solo móviles de 64 bits (casi todos); reduce mucho el tamaño del APK.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    androidResources { noCompress += listOf("onnx") }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.20.0")
    implementation("org.opencv:opencv:4.9.0")
}
