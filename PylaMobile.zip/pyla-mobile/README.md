# Pyla Mobile

App Android que juega sola a Brawl Stars, portando a móvil la IA de [PylaAI](https://github.com/PylaAI/PylaAI)
(licencia CC BY-NC 4.0: solo uso personal, no comercial). Úsala **solo con una cuenta secundaria**:
los bots incumplen las normas de Supercell y pueden provocar el baneo.

## Cómo funciona

| PylaAI (PC) | Pyla Mobile |
|---|---|
| scrcpy captura el móvil | MediaProjection (captura a 540 px de alto) |
| ADB simula toques | Servicio de accesibilidad: un dedo mantenido para el joystick + toques |
| Python + onnxruntime | Kotlin + ONNX Runtime Android, **mismos modelos** (`mainInGameModel.onnx`, `tileDetector.onnx`) |
| state_finder.py (plantillas) | OpenCV Android, mismas plantillas y regiones |
| playstyles `.pyla` | `Policy.kt`: acercarse hasta el rango seguro, huir si están cerca, atacar si es alcanzable, super/gadget/hipercarga, desatasco |

Modelos, plantillas y rangos de brawlers se descargan de PylaAI durante la compilación (no están en este ZIP).

## Compilar sin ordenador (GitHub Actions)

1. Crea un repositorio nuevo en GitHub (puede ser privado).
2. Sube todo el contenido de esta carpeta. La carpeta oculta `.github/workflows/build.yml` hay que crearla a mano:
   "Add file → Create new file", escribe `.github/workflows/build.yml` como nombre y pega el contenido.
3. En la pestaña **Actions** se lanza "Compilar APK" (o pulsa *Run workflow*). Tarda unos 6-10 min.
4. Descarga el artefacto **PylaMobile-apk**, descomprímelo e instala `app-debug.apk`.

## Primer uso

1. Abre la app. Pulsa **Activar servicio de accesibilidad** y activa "Pyla Mobile (toques)".
   Si Android lo bloquea (apps instaladas fuera de la Play Store): Ajustes → Apps → Pyla Mobile → ⋮ → *Permitir ajustes restringidos*.
2. Permite **mostrar sobre otras apps** y las notificaciones.
3. Elige tu brawler y hacia dónde avanzar si no ve enemigos.
4. En Brawl Stars elige tú el brawler y el modo (el bot no los cambia). Pon el juego en horizontal.
5. Pulsa **Iniciar bot** (acepta la captura de pantalla). Se abre Brawl Stars y aparece el panel flotante.
6. **Calibra los botones** con 🎯: arrastra cada punto amarillo encima de su botón real (joystick, ataque, super, gadget, hipercarga, Jugar) y vuelve a pulsar 🎯. Es lo más importante en móviles alargados o con muesca.

Panel: ⏸ pausa · 🎯 calibrar · 🐞 cajas de depuración (empeora algo la detección) · ✖ parar.

## Límites conocidos (versión 1)

- Probado el núcleo (decodificación de modelos, paredes, estrategia) contra la salida real de los modelos;
  la parte Android no se ha podido ejecutar en un móvil real, así que espera ajustes en la primera prueba.
- Rendimiento: 5-10 fps según el móvil. Si va lento, prueba NNAPI en los ajustes.
- Estrategia sencilla (una por dirección o seguidor). No hay selección automática de brawler ni seguimiento de trofeos.
- Las pantallas de menú se reconocen con las plantillas de PylaAI hechas para 16:9; en pantallas muy alargadas pueden fallar sin calibrar.
